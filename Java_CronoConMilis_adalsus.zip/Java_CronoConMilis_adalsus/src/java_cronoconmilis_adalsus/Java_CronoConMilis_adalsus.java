/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package java_cronoconmilis_adalsus;

import static java_cronoconmilis_adalsus.JFrameCCM_dlss.reloj_main;


/**
 *
 * @author adalsus -> www.bit.ly/adalsus
 */
public class Java_CronoConMilis_adalsus {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Llama al método
        reloj_main(new String[] {"00","00","00"});
    }
    
}
